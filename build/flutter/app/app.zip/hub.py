import sqlite3
import flet as ft

# Importação dos módulos do projeto
import campeonato
import elenco
import tatica
import academia
import loja
import partida


# Reutiliza o construtor de escudos do partida.py
from partida import construir_escudo


def obter_dados_time(id_usuario):
    """Procura as informações completas do clube, saldo, nível, EXP e diamantes na BD."""
    conn = sqlite3.connect('meu_manager.db')
    cursor = conn.cursor()

    cursor.execute("""
        SELECT t.id, t.nome, 
               COALESCE(t.cor_1, 'Azul'), COALESCE(t.cor_2, 'Vermelho'), 
               COALESCE(t.cor_3, 'Amarelo'), COALESCE(t.cor_4, 'Branco'),
               t.moedas_free, u.diamantes,
               COALESCE(u.nivel, 1), COALESCE(u.exp, 0)
        FROM times t
        INNER JOIN usuarios u ON u.id = t.id_usuario
        WHERE t.id_usuario = ?
    """, (id_usuario,))
    time = cursor.fetchone()
    conn.close()
    return time


def obter_jogadores(id_time):
    """Procura a lista de jogadores da equipa para exibir no Hub."""
    conn = sqlite3.connect('meu_manager.db')
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, nome, posicao, titular, estrelas, velocidade, finalizacao, drible, passe, defesa
        FROM jogadores WHERE id_time = ? ORDER BY titular DESC, posicao ASC
    """, (id_time,))
    jogadores = cursor.fetchall()
    conn.close()
    return jogadores


def obter_cor_card_por_estrelas(estrelas):
    """Define as cores de fundo e borda baseadas na quantidade de estrelas."""
    if estrelas <= 2:
        return {
            "border": ft.colors.BROWN_400,
            "bg": "#2A1810",  # Bronze
            "categoria": "BRONZE"
        }
    elif estrelas <= 4:
        return {
            "border": ft.colors.GREY_400,
            "bg": "#1E293B",  # Prata
            "categoria": "PRATA"
        }
    else:  # 5 Estrelas
        return {
            "border": ft.colors.AMBER_400,
            "bg": "#3B2607",  # Ouro
            "categoria": "OURO"
        }


def carregar_hub(page: ft.Page, id_usuario: int):
    page.clean()
    page.title = "FootManager - Central do Clube"
    page.bgcolor = "#0F172A"
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.padding = 20
    page.scroll = ft.ScrollMode.AUTO

    time = obter_dados_time(id_usuario)

    if not time:
        page.add(
            ft.Text("⚠️ Nenhuma equipa encontrada para este utilizador.",
                    color=ft.colors.RED_400, size=18)
        )
        return

    (id_time, nome_time, c1, c2, c3, c4,
     moedas_free, diamantes, nivel, exp) = time

    jogadores = obter_jogadores(id_time)

    # --- CÁLCULO DE EXP PARA O PRÓXIMO NÍVEL ---
    exp_necessaria = nivel * 100
    progresso_exp = min(1.0, exp / exp_necessaria) if exp_necessaria > 0 else 0.0

    # Escudo Dinâmico
    escudo_clube = construir_escudo(c1, c2, c3, c4, tamanho=0.7)

    # --- CABEÇALHO DO HUB ---
    header = ft.Container(
        content=ft.Row([
            # Lado Esquerdo: Escudo + Nome + Nível/EXP
            ft.Row([
                escudo_clube,
                ft.Column([
                    ft.Text(nome_time.upper(), size=22,
                            weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
                    ft.Row([
                        ft.Container(
                            content=ft.Text(
                                f"NÍVEL {nivel}", size=11, weight=ft.FontWeight.BOLD, color=ft.colors.BLACK),
                            bgcolor=ft.colors.AMBER_400, padding=ft.padding.symmetric(horizontal=6, vertical=2), border_radius=4
                        ),
                        ft.Text(
                            f"Plantel: {len(jogadores)} Jogadores", size=12, color=ft.colors.GREY_400),
                    ], spacing=10),
                    ft.Container(height=2),
                    # Barra de EXP
                    ft.Column([
                        ft.Row([
                            ft.Text("EXP", size=10, color=ft.colors.GREY_400,
                                    weight=ft.FontWeight.BOLD),
                            ft.Text(f"{exp} / {exp_necessaria}",
                                    size=10, color=ft.colors.GREY_400)
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, width=220),
                        ft.ProgressBar(value=progresso_exp, width=220,
                                       color=ft.colors.AMBER_400, bgcolor="#0F172A")
                    ], spacing=2)
                ], spacing=3)
            ], spacing=15),

            # Lado Direito: Moedas e Diamantes
            ft.Row([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.icons.MONETIZATION_ON,
                                color=ft.colors.AMBER, size=20),
                        ft.Text(f"{moedas_free}", size=16,
                                weight=ft.FontWeight.BOLD, color=ft.colors.WHITE)
                    ], spacing=5),
                    bgcolor="#0F172A", padding=10, border_radius=10
                ),
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.icons.DIAMOND,
                                color=ft.colors.CYAN_300, size=20),
                        ft.Text(f"{diamantes}", size=16,
                                weight=ft.FontWeight.BOLD, color=ft.colors.WHITE)
                    ], spacing=5),
                    bgcolor="#0F172A", padding=10, border_radius=10
                ),
            ], spacing=12)
        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
        width=950, bgcolor="#1E293B", padding=15, border_radius=15
    )

    # --- CARDS DE NAVEGAÇÃO ---
    card_elenco = ft.Container(
        content=ft.Column([
            ft.Icon(ft.icons.GROUPS, size=36, color=ft.colors.BLUE_400),
            ft.Text("Plantel", size=16, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            ft.Text("Gerir Jogadores", size=11, color=ft.colors.GREY_400)
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        width=170, height=120, bgcolor="#1E293B", border_radius=12, ink=True,
        on_click=lambda e: elenco.carregar_elenco(page, id_usuario, lambda id_u: carregar_hub(page, id_u))
    )

    card_tatica = ft.Container(
        content=ft.Column([
            ft.Icon(ft.icons.SPORTS, size=36, color=ft.colors.GREEN_400),
            ft.Text("Tática", size=16, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            ft.Text("Formação & Onze", size=11, color=ft.colors.GREY_400)
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        width=170, height=120, bgcolor="#1E293B", border_radius=12, ink=True,
        on_click=lambda e: tatica.carregar_tatica(page, id_usuario, lambda id_u: carregar_hub(page, id_u))
    )

    card_academia = ft.Container(
        content=ft.Column([
            ft.Icon(ft.icons.FITNESS_CENTER, size=36, color=ft.colors.ORANGE_400),
            ft.Text("Academia", size=16, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            ft.Text("Evoluir Atributos", size=11, color=ft.colors.GREY_400)
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        width=170, height=120, bgcolor="#1E293B", border_radius=12, ink=True,
        on_click=lambda e: academia.carregar_academia(page, id_usuario, lambda id_u: carregar_hub(page, id_u))
    )

    card_loja = ft.Container(
        content=ft.Column([
            ft.Icon(ft.icons.SHOPPING_BAG, size=36, color=ft.colors.AMBER_400),
            ft.Text("Loja", size=16, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            ft.Text("Comprar Pacotes", size=11, color=ft.colors.GREY_400)
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        width=170, height=120, bgcolor="#1E293B", border_radius=12, ink=True,
        on_click=lambda e: loja.carregar_loja(page, id_usuario, lambda id_u: carregar_hub(page, id_u))
    )

    card_jogar = ft.Container(
        content=ft.Column([
            ft.Icon(ft.icons.EMOJI_EVENTS, size=36, color=ft.colors.AMBER_400),
            ft.Text("Campeonato", size=16, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
            ft.Text("Copa Mata-Mata", size=11, color=ft.colors.GREY_400)
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        width=170, height=120, bgcolor="#1E293B", border_radius=12, ink=True,
        on_click=lambda e: campeonato.carregar_campeonato(page, id_usuario, lambda id_u: carregar_hub(page, id_u))
    )

    grid_menu = ft.Row(
        [card_elenco, card_tatica, card_academia, card_loja, card_jogar],
        spacing=15, alignment=ft.MainAxisAlignment.CENTER, wrap=True, width=950
    )

    # --- CARDS DOS JOGADORES ---
    def criar_card_mini_jogador(j):
        _, nome, pos, titular, estrelas, vel, fin, dri, pas, def_stat = j
        estilo = obter_cor_card_por_estrelas(estrelas)
        status_txt = "TITULAR" if titular == 1 else "SUPLENTE"
        status_cor = ft.colors.GREEN_400 if titular == 1 else ft.colors.GREY_500

        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Container(
                        content=ft.Text(pos, size=10, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
                        bgcolor="#0F172A", padding=ft.padding.symmetric(horizontal=6, vertical=2), border_radius=4
                    ),
                    ft.Text(status_txt, size=10, weight=ft.FontWeight.BOLD, color=status_cor)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),

                ft.Text(nome, size=13, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, overflow=ft.TextOverflow.ELLIPSIS),
                ft.Text("⭐ " * estrelas, size=11),

                ft.Divider(color=ft.colors.GREY_800, height=10),

                ft.Row([
                    ft.Text(f"VEL {vel}", size=10, color=ft.colors.GREY_300),
                    ft.Text(f"FIN {fin}", size=10, color=ft.colors.GREY_300),
                    ft.Text(f"DEF {def_stat}", size=10, color=ft.colors.GREY_300),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
            ], spacing=5, alignment=ft.MainAxisAlignment.CENTER),
            width=170,
            height=130,
            bgcolor=estilo["bg"],
            border_radius=10,
            padding=10,
            border=ft.border.all(1.5, estilo["border"])
        )

    cards_jogadores = [criar_card_mini_jogador(j) for j in jogadores[:10]]

    seccao_destaques = ft.Column([
        ft.Text("🌟 DESTAQUES DO PLANTEL", size=18, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE),
        ft.Row(cards_jogadores, wrap=True, spacing=15, alignment=ft.MainAxisAlignment.CENTER, width=950)
    ], spacing=15)

    # --- MONTAGEM DA PÁGINA ---
    page.add(
        header,
        ft.Container(height=15),
        grid_menu,
        ft.Container(height=25),
        seccao_destaques
    )


if __name__ == "__main__":
    def main(page: ft.Page):
        carregar_hub(page, id_usuario=1)

    ft.app(target=main)